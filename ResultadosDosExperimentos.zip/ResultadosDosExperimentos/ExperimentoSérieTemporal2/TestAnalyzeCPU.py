import pyautogui
import psutil
import time
import threading
import uiautomation as auto
from pywinauto import Application
from pywinauto.mouse import click

def abrir_samsung_gallery():
    # Pressiona a tecla Windows para abrir o menu Iniciar
    pyautogui.press("win")
    time.sleep(1)  # Aguarda o menu iniciar abrir

    # Digita "Samsung Gallery"
    pyautogui.write("Samsung Gallery", interval=0.1)
    time.sleep(2)  # Aguarda os resultados aparecerem

    # Pressiona Enter para abrir o aplicativo
    pyautogui.press("enter")
    time.sleep(5)  # Aguarda o Samsung Gallery abrir completamente

def clicar_settings():
    try:
        # Conectar ao Samsung Gallery
        app = Application(backend="uia").connect(title_re="Samsung Gallery")

        # Obtém a janela principal do Samsung Gallery
        janela = app.window(title_re="Samsung Gallery")

        # Clicar no botão Settings
        settings_button = janela.child_window(auto_id="SettingsButton")
        settings_button.click_input()
        time.sleep(5)

        print("Setting button clicado com sucesso!")
    except Exception as e:
        print(f"Erro ao clicar no botão: {e}")

def monitorar_cpu(janela, parar_evento, start_time):
    """
    Mede o uso de CPU a cada 10s, iniciando 10s após o clique,
    e encerrando ao completar 60s desde o clique.
    """
    tempo_max = 60  # segundos
    sample_time = start_time + 10  # primeira medição aos 10s
    end_time = start_time + tempo_max

    while not parar_evento.is_set() and sample_time <= end_time:
        # Espera até o instante da próxima amostra (10s, 20s, ... 60s)
        wait = sample_time - time.time()
        if wait > 0:
            time.sleep(wait)

        try:
            uso_cpu = psutil.cpu_percent(interval=1)  # mede no instante da amostra
            elapsed = int(sample_time - start_time)
            print(f"[{elapsed:02d}s] Uso de CPU: {uso_cpu:.2f}%")
        except Exception as e:
            print(f"Erro ao medir CPU: {e}")

        sample_time += 10  # próxima amostra em +10s

    print("Monitoramento de CPU finalizado (atingiu 1 minuto).")
    parar_evento.set()
    
def clicar_analysebutton():
    try:
        # Conectar ao Samsung Gallery
        app = Application(backend="uia").connect(title_re="Samsung Gallery")

        # Obtém a janela principal do Samsung Gallery
        janela = app.window(title_re="Samsung Gallery")

        # Localiza e clica no botão SettingsImageAnalysisButton
        settings_button = None
        for _ in range(10):  # tenta por até ~10s
            try:
                settings_button = janela.child_window(auto_id="SettingsImageAnalysisButton")
                if settings_button.exists():
                    break
            except:
                pass
            time.sleep(1)

        if not settings_button or not settings_button.exists():
            print("❌ Botão 'SettingsImageAnalysisButton' não encontrado!")
            return

        settings_button.click_input()
        click_time = time.time()  # referência do "instante do clique"
        print("Analyze now button clicado com sucesso!")

        # Inicia o monitoramento de CPU cronometrado a partir do clique
        parar_evento = threading.Event()
        monitor_thread = threading.Thread(target=monitorar_cpu, args=(janela, parar_evento, click_time))
        monitor_thread.start()

        # (Opcional) Aguarde a conclusão das amostras de 1 minuto:
        monitor_thread.join()

    except Exception as e:
        print(f"Erro ao clicar no botão: {e}")


# Executa as funções
abrir_samsung_gallery()
clicar_settings()
clicar_analysebutton()
