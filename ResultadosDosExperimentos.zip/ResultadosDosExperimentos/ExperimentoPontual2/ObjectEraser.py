import pyautogui
import psutil
import time
import uiautomation as auto
from pywinauto import Application
from pywinauto.mouse import click

def abrir_samsung_gallery():
    # Pressiona a tecla Windows para abrir o menu Iniciar
    pyautogui.press("win")
    time.sleep(1)  # Aguarda o menu iniciar abrir

    # Digita "Samsung Gallery"
    pyautogui.write("Samsung Gallery", interval=0.1)
    time.sleep(2)  # Aguarda os resultados aparecerem

    # Pressiona Enter para abrir o aplicativo
    pyautogui.press("enter")
    time.sleep(5)  # Aguarda o Samsung Gallery abrir completamente

def pesquisar_e_clicar_thumbnail():
    try:
        # Conectar ao Samsung Gallery
        app = Application(backend="uia").connect(title_re="Samsung Gallery")

        # Obtém a janela principal do Samsung Gallery
        janela = app.window(title_re="Samsung Gallery")

        # Localiza o campo de pesquisa 
        campo_pesquisa = janela.child_window(control_type="Edit") 
        campo_pesquisa.click_input()
        #campo_pesquisa.type_keys("machupicchu", with_spaces=True)
        pyautogui.write("machupicchu", interval=0.1)
        pyautogui.press("enter")
        time.sleep(2)  # Aguarda os resultados aparecerem

        # Clicar no primeiro item com AutomationId = Thumbnail
        primeiro_thumbnail = janela.child_window(auto_id="Thumbnail")
        primeiro_thumbnail.click_input()
        time.sleep(5)

        print("Pesquisa realizada e primeiro resultado clicado com sucesso!")
    except Exception as e:
        print(f"Erro ao realizar a pesquisa e clicar no primeiro resultado: {e}")

def clicar_edit_option():
    try:        
        # Conectar ao Samsung Gallery
        app = Application(backend="uia").connect(title="machupicchu-pareja-desktop-.png ‎- Samsung Gallery")

        # Obtém a janela principal do Samsung Gallery
        janela = app.window(title="machupicchu-pareja-desktop-.png ‎- Samsung Gallery")

         # Localiza o botão "Mais opções" pelo AutomationId
        botao_edit = app.window().child_window(auto_id="ViewerEditAppBarButton" , control_type="Button")

        if botao_edit.exists():
            botao_edit.click_input()
            time.sleep(3)
            print("Botão 'Edit' clicado com sucesso!")
        else:
            print("Botão 'Edit' não encontrado.")

    except Exception as e:
        print(f"Erro ao clicar no botão 'Edit': {e}")

def clicar_draw():       
        # Conectar ao Samsung Gallery
        app = Application(backend="uia").connect(title="machupicchu-pareja-desktop-.png ‎- Samsung Gallery")

        # Obtém a janela principal do Samsung Gallery
        janela = app.window(title="machupicchu-pareja-desktop-.png ‎- Samsung Gallery")

         # Localiza o botão "Mais opções" pelo AutomationId
        botao_draw = app.window().child_window(auto_id="PhotoEditorPenDrawingPanelAppBarButton", control_type="Button")

        click(coords=(1711,333))

def clicar_e_arrastar_para_baixo_inkcanvas():
    window_title = "machupicchu-pareja-desktop-.png ‎- Samsung Gallery"

    # Etapa 1: Verifica e ativa a janela
    window = auto.WindowControl(Name=window_title)

    if not window.Exists(5):
        print(f"A janela '{window_title}' não está aberta.")
        return

    window.SetActive()
    window.SetFocus()
    time.sleep(1)

    # Etapa 2: Localiza o controle InkCanvas
    ink_canvas = window.Control(AutomationId='InkCanvas')
    if not ink_canvas.Exists(3):
        print("Elemento 'InkCanvas' não encontrado.")
        return

    rect = ink_canvas.BoundingRectangle
    center_x = rect.left + (rect.right - rect.left) // 2
    center_y = rect.top + (rect.bottom - rect.top) // 2

    def arrastar_para_baixo(x, y, distancia=100, passos=10):
        pyautogui.moveTo(x, y, duration=0.2)
        pyautogui.mouseDown()
        for i in range(1, passos + 1):
            passo_y = y + int((distancia * i) / passos)
            pyautogui.moveTo(x, passo_y, duration=0.03)
        pyautogui.mouseUp()
        print("Arraste realizado.")

    print("🔹 Primeira etapa: desenhando...")
    arrastar_para_baixo(center_x, center_y)

    # Etapa 3: Clica no botão da borracha
    eraser_button = window.Control(AutomationId='DrawingControlEraserButton')
    if not eraser_button.Exists(3):
        print("Botão 'DrawingControlEraserButton' não encontrado.")
        return

    eraser_rect = eraser_button.BoundingRectangle
    eraser_x = eraser_rect.left + (eraser_rect.right - eraser_rect.left) // 2
    eraser_y = eraser_rect.top + (eraser_rect.bottom - eraser_rect.top) // 2

    pyautogui.moveTo(eraser_x, eraser_y, duration=0.2)
    pyautogui.click()
    print("🔸 Borracha ativada.")

    time.sleep(0.5)

    print("🔹 Segunda etapa: apagando com a borracha...")
    arrastar_para_baixo(center_x, center_y)

    print("✅ Ação finalizada com sucesso.")

def clicar_object_eraser_option_e_monitorar_tempo_resposta():
        
        # Conectar ao Samsung Gallery
        app = Application(backend="uia").connect(title="machupicchu-pareja-desktop-.png ‎- Samsung Gallery")

        # Obtém a janela principal
        janela = app.window(title="machupicchu-pareja-desktop-.png ‎- Samsung Gallery")

        # Localiza o botão "Object Eraser" pelo AutomationId
        botao_object = janela.child_window(auto_id="PhotoEditorOpenObjectEraserPanelAppBarButton", control_type="Button")

        click(coords=(1711,525))

        start_time = time.time()  # Inicia a medição de tempo

            # Aguarda até que o elemento ObjectEraserGrid apareça ou timeout de 10s
        for _ in range(100):  # 100 tentativas de 0.1s = 10 segundos
                if janela.child_window(auto_id="ObjectEraserGrid").exists(timeout=0.1):
                    end_time = time.time()
                    tempo_resposta = end_time - start_time
                    print(f"O painel 'Object Eraser' apareceu após {tempo_resposta:.2f} segundos.")
                    return
                time.sleep(0.1)


# Executa as funções
abrir_samsung_gallery()
pesquisar_e_clicar_thumbnail()
clicar_edit_option()
clicar_draw()
clicar_e_arrastar_para_baixo_inkcanvas()
clicar_object_eraser_option_e_monitorar_tempo_resposta()