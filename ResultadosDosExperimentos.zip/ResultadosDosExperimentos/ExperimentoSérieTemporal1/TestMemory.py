import pyautogui
import psutil
import time
import uiautomation as auto
from pywinauto import Application
from pywinauto.mouse import click

def abrir_samsung_gallery():
    # Pressiona a tecla Windows para abrir o menu Iniciar
    pyautogui.press("win")
    time.sleep(1)  # Aguarda o menu iniciar abrir

    # Digita "Samsung Gallery"
    pyautogui.write("Samsung Gallery", interval=0.1)
    time.sleep(2)  # Aguarda os resultados aparecerem

    # Pressiona Enter para abrir o aplicativo
    pyautogui.press("enter")
    time.sleep(5)  # Aguarda o Samsung Gallery abrir completamente

def clicar_thumbnail():
    try:
        # Conectar ao Samsung Gallery
        app = Application(backend="uia").connect(title_re="Samsung Gallery")

        # Obtém a janela principal do Samsung Gallery
        janela = app.window(title_re="Samsung Gallery")

        # Clicar no primeiro item com AutomationId = Thumbnail
        primeiro_thumbnail = janela.child_window(auto_id="Thumbnail")
        click(coords=(936,255))
        #primeiro_thumbnail.click_input()
        time.sleep(5)

        print("Primeiro resultado clicado com sucesso!")
    except Exception as e:
        print(f"Erro ao clicar no primeiro resultado: {e}")

def get_memory_usage(process_name_contains="Gallery"):
    """Retorna uso de memória (MB) de um processo cujo nome contém determinado termo"""
    for proc in psutil.process_iter(['name', 'memory_info']):
        try:
            if process_name_contains.lower() in proc.info['name'].lower():
                return proc.info['memory_info'].rss / (1024 * 1024)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    return None

def clicar_next_button():
    # Conectar ao Samsung Gallery
    app = Application(backend="uia").connect(title="10.jpg ‎- Samsung Gallery")
    janela = app.window(title="10.jpg ‎- Samsung Gallery")

    # Localiza o botão "MyFlipView" (galeria de imagens)
    botao_draw = janela.child_window(auto_id="MyFlipView")

    # Medir o uso de memória antes do primeiro clique
    mem_0 = get_memory_usage()
    if mem_0 is not None:
        print(f"Uso de memória antes do clique: {mem_0:.2f} MB")
    else:
        print("⚠️ Processo não encontrado antes do clique.")

    # Início dos 30 segundos de cliques (60 cliques = 2 por segundo)
    start_time = time.time()
    for i in range(60):  # 60 cliques = 2 por segundo durante 30s
        click(coords=(1711, 500))
        time.sleep(0.5)  # intervalo de 0.5s

        elapsed = time.time() - start_time

        if i == 19:  # após 10s (20 cliques)
            mem_10 = get_memory_usage()
            if mem_10 is not None:
                print(f"Uso de memória após 10s: {mem_10:.2f} MB")
            else:
                print("⚠️ Processo não encontrado após 10s.")
        elif i == 39:  # após 20s (40 cliques)
            mem_20 = get_memory_usage()
            if mem_20 is not None:
                print(f"Uso de memória após 20s: {mem_20:.2f} MB")
            else:
                print("⚠️ Processo não encontrado após 20s.")
        elif i == 59:  # após 30s (60 cliques)
            mem_30 = get_memory_usage()
            if mem_30 is not None:
                print(f"Uso de memória após 30s: {mem_30:.2f} MB")
            else:
                print("⚠️ Processo não encontrado após 30s.")

def registrar_memoria_pos_cliques(delay_inicial=1, intervalo=10, repeticoes=6, processo="Gallery"):
    """Aguarda delay_inicial (segundos), e registra uso de memória a cada intervalo (segundos) por 'repeticoes' vezes"""
    print(f"\nAguardando {delay_inicial} segundos antes de iniciar coleta pós-cliques...")
    time.sleep(delay_inicial)

    for i in range(repeticoes):
        mem = get_memory_usage(processo)
        if mem is not None:
            print(f"Uso de memória após {delay_inicial + (i+1)*intervalo}s: {mem:.2f} MB")
        else:
            print(f"⚠️ Processo não encontrado após {delay_inicial + (i+1)*intervalo}s.")
        time.sleep(intervalo)


# Executa as funções
abrir_samsung_gallery()
clicar_thumbnail()
get_memory_usage()
clicar_next_button()
registrar_memoria_pos_cliques()